# Music-Player-Project
This repository contains dummy music player project made using html and css. 
